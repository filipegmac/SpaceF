<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceF - Cadastro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Cadastro</h1>
        <form action="../backend/register.php" method="POST">
            <input type="text" name="nome" placeholder="Nome" required>
            <input type="text" name="sobrenome" placeholder="Sobrenome" required>
            <input type="text" name="nome_mae" placeholder="Nome da Mãe" required>
            <input type="text" name="cpf" placeholder="CPF" required>
            <input type="text" name="endereco" placeholder="Endereço" required>
            <input type="date" name="data_nascimento" placeholder="Data de Nascimento" required>
            <input type="text" name="telefone" placeholder="Telefone" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Cadastrar</button>
        </form>
        <a href="index.php">Voltar ao Login</a>
    </div>
</body>
</html>