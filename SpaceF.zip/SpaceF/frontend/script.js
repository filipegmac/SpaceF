// frontend/script.js
document.addEventListener('DOMContentLoaded', () => {
    const toggleThemeButton = document.createElement('button');
    toggleThemeButton.innerText = 'Alternar Dia/Noite';
    toggleThemeButton.style.position = 'fixed';
    toggleThemeButton.style.top = '10px';
    toggleThemeButton.style.right = '10px';
    document.body.appendChild(toggleThemeButton);
  
    toggleThemeButton.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
    });
  });
  
  // Adicione o estilo para o modo escuro no CSS