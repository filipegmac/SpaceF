// backend/database.js
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(':memory:');

db.serialize(() => {
  db.run(`CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT,
    sobrenome TEXT,
    nome_mae TEXT,
    cpf TEXT,
    endereco TEXT,
    data_nascimento TEXT,
    telefone TEXT,
    email TEXT,
    senha TEXT
  )`);
});

module.exports = db;