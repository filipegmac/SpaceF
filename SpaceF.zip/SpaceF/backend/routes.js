// backend/routes.js
const express = require('express');
const router = express.Router();
const db = require('./database');
const bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));

router.post('/register', (req, res) => {
  const { nome, sobrenome, nome_mae, cpf, endereco, data_nascimento, telefone, email, senha } = req.body;
  db.run(`INSERT INTO users (nome, sobrenome, nome_mae, cpf, endereco, data_nascimento, telefone, email, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [nome, sobrenome, nome_mae, cpf, endereco, data_nascimento, telefone, email, senha], function(err) {
      if (err) {
        return res.status(500).send("Erro ao registrar usuário");
      }
      res.redirect('/sucesso.html');
    });
});

router.post('/login', (req, res) => {
  const { email, senha } = req.body;
  db.get(`SELECT * FROM users WHERE email = ? AND senha = ?`, [email, senha], (err, row) => {
    if (err || !row) {
      return res.status(401).send("Credenciais inválidas");
    }
    res.redirect(`/sucesso.html?nome=${row.nome}`);
  });
});

module.exports = router;