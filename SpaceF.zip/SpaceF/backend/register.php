<?php
require 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $nome_mae = $_POST['nome_mae'];
    $cpf = $_POST['cpf'];
    $endereco = $_POST['endereco'];
    $data_nascimento = $_POST['data_nascimento'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (nome, sobrenome, nome_mae, cpf, endereco, data_nascimento, telefone, email, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt->execute([$nome, $sobrenome, $nome_mae, $cpf, $endereco, $data_nascimento, $telefone, $email, $senha])) {
        header("Location: ../frontend/sucesso.php");
    } else {
        echo "Erro ao registrar usuário";
    }
}
?>