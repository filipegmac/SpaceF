#!/bin/bash

# Atualizar pacotes
sudo apt update

# Instalar Apache, PHP e MySQL
sudo apt install -y apache2 php libapache2-mod-php php-mysql mysql-server

# Configurar banco de dados
sudo mysql -e "CREATE DATABASE spacef;"
sudo mysql -e "CREATE USER 'spacef_user'@'localhost' IDENTIFIED BY 'password';"
sudo mysql -e "GRANT ALL PRIVILEGES ON spacef.* TO 'spacef_user'@'localhost';"
sudo mysql -e "FLUSH PRIVILEGES;"

# Configurar Apache
sudo cp -r /vagrant/spacef /var/www/html/
sudo chown -R www-data:www-data /var/www/html/spacef

# Reiniciar Apache
sudo systemctl restart apache2